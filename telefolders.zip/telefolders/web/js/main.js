import Main from "./components/MainWidget/index.js";

new Main().init()